const userinfo={
    userName:"暂未填写",
    userEmail:"暂未填写",
    userPhone:"暂未填写"
}
export default{
    userinfo
}